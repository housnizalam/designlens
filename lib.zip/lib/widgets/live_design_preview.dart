import 'dart:ui';

import 'design_gradient.dart';

import 'package:flutter/material.dart';

class LiveDesignPreview extends StatelessWidget {
  final Map<String, List<String>> answers;

  const LiveDesignPreview({super.key, required this.answers});

  String? answer(String id) {
    final values = answers[id];
    return values == null || values.isEmpty ? null : values.first;
  }

  Color? selectedColor(String id) {
    final value = answer(id);

    if (value == null || !RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(value)) {
      return null;
    }

    return Color(int.parse(value.substring(1), radix: 16) | 0xFF000000);
  }

  int optionIndex(String id, List<String> options) {
    return options.indexOf(answer(id) ?? '');
  }

  Color mix(Color first, Color second, double amount) {
    return Color.lerp(first, second, amount)!;
  }

  Color readableText(Color background) {
    return background.computeLuminance() > 0.45
        ? const Color(0xFF17202E)
        : Colors.white;
  }

  List<BoxShadow> makeShadows(int level, Color color, {bool darkMode = false}) {
    if (level == 0) return [];

    return [
      BoxShadow(
        color: mix(color, Colors.black, 0.45).withValues(
          alpha: darkMode ? 0.30 + level * 0.07 : 0.18 + level * 0.07,
        ),
        blurRadius: 7.0 + level * 8,
        spreadRadius: level * 0.4,
        offset: Offset(0, 2.0 + level * 3),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    // الألوان المختارة فعليًا.
    final chosenPrimary = selectedColor('primary_color');
    final chosenAccent = selectedColor('accent_color');

    // لا نعرض Gradient إلا عند اختياره صراحة.
    final gradientMode = answer('gradient_mode');

    final customGradientColor = selectedColor('gradient_custom_color');

    Color? gradientEnd;

    if (gradientMode == 'primary_accent') {
      gradientEnd = chosenAccent;
    } else if (gradientMode == 'primary_custom') {
      gradientEnd = customGradientColor;
    }

    final useGradient = chosenPrimary != null && gradientEnd != null;

    final gradientDirection = answer('gradient_direction') ?? 'diagonal';

    final gradientBalance =
        double.tryParse(answer('gradient_balance') ?? '') ?? 50.0;

    final Gradient? previewGradient = useGradient
        ? DesignGradient.build(
            first: chosenPrimary,
            second: gradientEnd,
            direction: gradientDirection,
            balance: gradientBalance,
          )
        : null;

    // رمادي محايد عند عدم الاختيار.
    final primary = chosenPrimary ?? const Color(0xFF64748B);

    final accent = chosenAccent ?? const Color(0xFF94A3B8);

    final hasPrimary = chosenPrimary != null;
    final hasAccent = chosenAccent != null;

    final strengthText = answer('primary_color_strength');

    final colorStrength =
        ((double.tryParse(strengthText ?? '') ?? 60.0) / 100.0).clamp(0.0, 1.0);

    final radiusIndex = optionIndex('corners', [
      'حواف حادة',
      'استدارة خفيفة',
      'استدارة متوسطة',
      'استدارة كبيرة',
      'استدارة كبيرة جدًا',
    ]);

    final radius = <double>[
      0,
      6,
      14,
      24,
      36,
    ][radiusIndex < 0 ? 2 : radiusIndex];

    final shadowIndex = optionIndex('shadows', [
      'مسطحة دون ظل',
      'ظل خفيف وناعم',
      'ظل واضح',
      'تبدو مرتفعة كثيرًا',
    ]);

    final shadowLevel = shadowIndex < 0 ? 0 : shadowIndex;

    final glassIndex = optionIndex('glass', [
      'لا، بطاقات عادية',
      'شفافية خفيفة جدًا',
      'شفافية متوسطة',
      'تأثير زجاجي واضح',
      'تأثير زجاجي قوي',
    ]);

    final glassLevel = glassIndex < 0 ? 0 : glassIndex;

    final themeAnswer = answer('theme') ?? '';
    final darkMode = themeAnswer.startsWith('داكنة');

    // ----- لوحة الألوان المشتقة -----

    final neutralBackground = darkMode
        ? const Color(0xFF131820)
        : const Color(0xFFF1F3F6);

    final neutralSurface = darkMode ? const Color(0xFF242B35) : Colors.white;

    final background = hasPrimary
        ? mix(neutralBackground, primary, 0.05 + colorStrength * 0.95)
        : neutralBackground;

    // final surface = hasPrimary
    //     ? mix(neutralSurface, primary, darkMode ? 0.18 : 0.08)
    //     : neutralSurface;

    final featureCardBackground = primary;

    // final foreground = darkMode ? Colors.white : const Color(0xFF1E293B);

    // final secondaryText = darkMode
    //     ? const Color(0xFFCBD5E1)
    //     : const Color(0xFF475569);

    final borderColor = mix(primary, neutralSurface, darkMode ? 0.50 : 0.65);

    final borderColorMode = answer('border_color_mode');

    final customBorderColor = selectedColor('border_custom_color');

    final Color effectiveBorderColor;

    if (borderColorMode == 'نفس اللون الإضافي الذي اخترته' &&
        chosenAccent != null) {
      effectiveBorderColor = chosenAccent;
    } else if (borderColorMode == 'أريد اختيار لون خاص للإطارات' &&
        customBorderColor != null) {
      effectiveBorderColor = customBorderColor;
    } else {
      effectiveBorderColor = borderColor;
    }

    // لون البطاقة الداخلية من الهوية.

    final demoCardColor = primary;

    // خلفية محايدة متباينة لإظهار الشفافية.
    // لا يوجد Gradient.

    final glassBackdrop = hasPrimary
        ? mix(
            mix(background, primary, 0.50),
            darkMode ? Colors.white : Colors.black,
            0.12,
          )
        : mix(background, neutralSurface, 0.50);

    final glassAlpha = <double>[1, 0.88, 0.65, 0.38, 0.18][glassLevel];

    final glassBlur = <double>[0, 2, 5, 9, 14][glassLevel];

    final shadows = makeShadows(shadowLevel, primary, darkMode: darkMode);

    final borderIndex = optionIndex('borders', [
      'دون إطار',
      'إطار خفيف',
      'إطار متوسط',
      'إطار واضح',
    ]);

    final borderWidth = <double>[
      0,
      0.8,
      1.8,
      3.5,
    ][borderIndex < 0 ? 1 : borderIndex];

    return Container(
      clipBehavior: Clip.antiAlias,

      decoration: BoxDecoration(
        color: previewGradient == null ? background : null,
        gradient: previewGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: effectiveBorderColor),
      ),

      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ----- الشريط العلوي -----

            Container(
              color: primary,
              padding: const EdgeInsets.all(17),
              child: Row(
                children: [
                  Icon(Icons.dashboard_outlined, color: accent),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'تطبيقي',
                      style: TextStyle(
                        color: readableText(primary),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Icon(Icons.menu, color: accent),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ----- العناوين -----

                  Text(
                    'مرحبًا بك',
                    style: TextStyle(
                      color: readableText(background),
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'اكتشف الخدمات المتاحة',
                    style: TextStyle(
                      color: readableText(background).withValues(alpha: 0.85),
                      fontSize: 13,
                    ),
                  ),

                  const SizedBox(height: 23),

                  // ----- البطاقات الثلاث -----
                  Row(
                    children: [
                      Expanded(
                        child: _PreviewFeatureCard(
                          icon: Icons.home_outlined,
                          label: 'الرئيسية',
                          color: accent,
                          background: featureCardBackground,
                          textColor: readableText(primary),
                          borderColor: effectiveBorderColor,
                          radius: radius,
                          shadow: shadows,
                          borderWidth: borderWidth,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _PreviewFeatureCard(
                          icon: Icons.star_outline,
                          label: 'المميزات',
                          color: accent,
                          background: featureCardBackground,
                          textColor: readableText(primary),
                          borderColor: effectiveBorderColor,
                          radius: radius,
                          shadow: shadows,
                          borderWidth: borderWidth,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _PreviewFeatureCard(
                          icon: Icons.person_outline,
                          label: 'الحساب',
                          color: accent,
                          background: featureCardBackground,
                          textColor: readableText(primary),
                          borderColor: effectiveBorderColor,
                          radius: radius,
                          shadow: shadows,
                          borderWidth: borderWidth,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 28),

                  // ----- البطاقة التجريبية -----
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: glassBackdrop,
                      borderRadius: BorderRadius.circular(radius),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(radius),
                        boxShadow: shadows,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(radius),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: glassBlur,
                            sigmaY: glassBlur,
                          ),
                          child: Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: demoCardColor.withValues(
                                alpha: glassAlpha,
                              ),
                              border: borderWidth == 0
                                  ? null
                                  : Border.all(
                                      color: effectiveBorderColor,
                                      width: borderWidth,
                                    ),
                              borderRadius: BorderRadius.circular(radius),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.widgets_outlined, color: accent),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        'بطاقة تجريبية',
                                        style: TextStyle(
                                          color: readableText(demoCardColor),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'هنا يظهر شكل البطاقة والألوان '
                                  'والظل الذي اخترته.',
                                  style: TextStyle(
                                    color: readableText(demoCardColor),
                                    fontSize: 12,
                                  ),
                                ),
                                const SizedBox(height: 16),

                                // عنصر ملون داخل البطاقة.
                                Container(
                                  height: 9,
                                  decoration: BoxDecoration(
                                    color: hasAccent ? accent : primary,
                                    borderRadius: BorderRadius.circular(radius),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ----- زر رئيسي -----
                  DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(radius),
                      boxShadow: shadows,
                    ),
                    child: FilledButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.arrow_forward),
                      label: const Text('ابدأ الآن'),
                      style: FilledButton.styleFrom(
                        backgroundColor: hasAccent ? accent : primary,
                        foregroundColor: readableText(
                          hasAccent ? accent : primary,
                        ),
                        elevation: 0,
                        minimumSize: const Size.fromHeight(50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(radius),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ----- عنصر ثانوي -----
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: primary,
                      borderRadius: BorderRadius.circular(radius),
                      border: borderWidth == 0
                          ? null
                          : Border.all(
                              color: effectiveBorderColor,
                              width: borderWidth,
                            ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: accent),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'عنصر إضافي من تصميمك',
                            style: TextStyle(
                              color: readableText(primary),
                              fontSize: 13,
                            ),
                          ),
                        ),
                        Icon(
                          Icons.chevron_left,
                          color: hasAccent ? accent : primary,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PreviewFeatureCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color background;
  final Color textColor;
  final Color borderColor;
  final double radius;
  final List<BoxShadow> shadow;
  final double borderWidth;

  const _PreviewFeatureCard({
    required this.icon,
    required this.label,
    required this.color,
    required this.background,
    required this.textColor,
    required this.borderColor,
    required this.radius,
    required this.shadow,
    required this.borderWidth,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 85),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(radius),
        border: borderWidth == 0
            ? null
            : Border.all(
                color: borderColor.withValues(alpha: 0.70),
                width: borderWidth,
              ),
        boxShadow: shadow,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 27),
          const SizedBox(height: 8),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              label,
              style: TextStyle(
                color: textColor,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
