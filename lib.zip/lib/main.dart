import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'widgets/scale_question_widget.dart';
import 'widgets/live_design_preview.dart';
import 'widgets/color_question_widget.dart';
import 'widgets/color_preferences_widget.dart';
import 'widgets/gradient_question_widget.dart';

void main() {
  runApp(const DesignLensApp());
}

class DesignLensApp extends StatelessWidget {
  const DesignLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DesignLens',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2455A4)),
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
      ),
      home: const HomeScreen(),
    );
  }
}

// ---------------- HOME ----------------

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DesignLens'), centerTitle: true),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(
                Icons.palette_outlined,
                size: 88,
                color: Color(0xFF2455A4),
              ),
              const SizedBox(height: 24),
              Text(
                'حوّل فكرة العميل إلى تصميم واضح',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 16),
              const Text(
                'اختر الأشكال والألوان التي تعجبك، '
                'وسنحوّل اختياراتك إلى وصف تصميم احترافي.',
                textAlign: TextAlign.center,
              ),
              const Spacer(),
              FilledButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => const QuestionnaireScreen(),
                    ),
                  );
                },
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('بدء تصميم جديد'),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- QUESTION MODEL ----------------

enum QuestionType {
  singleChoice,
  multiChoice,
  cornerPreview,
  shadowPreview,
  glassPreview,
  colorChoice,
  colorAvoid,
  colorStylePreview,
  gradientChoice,
  borderPreview,
  borderColorChoice,
  scale,
  shapePreview,
}

class DesignQuestion {
  final String id;
  final String title;
  final String description;
  final QuestionType type;
  final List<String> options;
  final int maxSelections;

  const DesignQuestion({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.options,
    this.maxSelections = 1,
  });
}

// ---------------- QUESTIONS DATA ----------------

const List<DesignQuestion> questions = [
  DesignQuestion(
    id: 'personality',
    title: 'كيف تريد أن يشعر الناس عند فتح تطبيقك؟',
    description: 'اختر حتى ثلاثة أوصاف تناسب فكرتك.',
    type: QuestionType.multiChoice,
    maxSelections: 3,
    options: [
      'جدي واحترافي',
      'فاخر وأنيق',
      'حديث ومتطور',
      'تقني وذكي',
      'بسيط ومريح',
      'ودود وقريب من الناس',
      'شبابي ونشيط',
      'مرح ومسلٍّ',
      'هادئ',
      'قوي وملفت للنظر',
      'رسمي',
      'مستقبلي',
      'طبيعي',
      'طفولي',
    ],
  ),
  DesignQuestion(
    id: 'audience',
    title: 'من سيستخدم هذا التطبيق غالبًا؟',
    description: 'اختر الفئة الأقرب لجمهور المشروع.',
    type: QuestionType.singleChoice,
    options: [
      'أطفال',
      'مراهقون',
      'شباب',
      'بالغون',
      'كبار السن',
      'موظفون وشركات',
      'جميع الفئات',
    ],
  ),
  DesignQuestion(
    id: 'corners',
    title: 'أي شكل للحواف يعجبك أكثر؟',
    description: 'لاحظ زوايا البطاقات الخمس. اختر الشكل الأقرب لذوقك.',
    type: QuestionType.cornerPreview,
    options: [
      'حواف حادة',
      'استدارة خفيفة',
      'استدارة متوسطة',
      'استدارة كبيرة',
      'استدارة كبيرة جدًا',
    ],
  ),
  DesignQuestion(
    id: 'shadows',
    title: 'كيف تفضل أن تظهر البطاقات؟',
    description: 'كل بطاقة تحتوي المحتوى نفسه. الاختلاف في الظل والارتفاع.',
    type: QuestionType.shadowPreview,
    options: ['مسطحة دون ظل', 'ظل خفيف وناعم', 'ظل واضح', 'تبدو مرتفعة كثيرًا'],
  ),
  DesignQuestion(
    id: 'glass',
    title: 'هل يعجبك أن تظهر الخلفية من خلال البطاقات؟',
    description: 'قارن بين البطاقات العادية والشفافة واختر ما يعجبك.',
    type: QuestionType.glassPreview,
    options: [
      'لا، بطاقات عادية',
      'شفافية خفيفة جدًا',
      'شفافية متوسطة',
      'تأثير زجاجي واضح',
      'تأثير زجاجي قوي',
    ],
  ),
  DesignQuestion(
    id: 'primary_color',
    title: 'ما اللون الأساسي الذي يعجبك لتطبيقك؟',
    description:
        'هذا اللون سيعطي التطبيق شخصيته الأساسية. '
        'يمكنك اختيار لون جاهز، أو تحديد لون بنفسك.',
    type: QuestionType.colorChoice,
    options: [],
  ),
  DesignQuestion(
    id: 'accent_color',
    title: 'ما اللون الإضافي الذي تريد استخدامه؟',
    description:
        'لون يستخدم بجانب اللون الأساسي، مثل الأزرار '
        'والعناصر التي نريد لفت الانتباه إليها.',
    type: QuestionType.colorChoice,
    options: [],
  ),

  DesignQuestion(
    id: 'avoided_colors',
    title: 'هل توجد ألوان لا تريد رؤيتها في تطبيقك؟',
    description:
        'اختر أي عدد من الألوان التي لا تحبها. '
        'يمكنك ترك السؤال دون اختيار.',
    type: QuestionType.colorAvoid,
    options: [],
  ),
  DesignQuestion(
    id: 'color_style',
    title: 'أي مجموعة ألوان تعجبك أكثر؟',
    description:
        'انظر إلى الأمثلة واختر الألوان الأقرب لذوقك. '
        'هذه مجرد أمثلة وليست ألوانًا إلزامية.',
    type: QuestionType.colorStylePreview,
    options: [
      'هادئة وغير صارخة',
      'قوية وزاهية',
      'ناعمة وفاتحة',
      'داكنة',
      'فاتحة ومشرقة',
      'درجات من لون واحد',
      'ألوان متدرجة وممزوجة',
      'أترك الاختيار للمصمم',
    ],
  ),
  DesignQuestion(
    id: 'theme',
    title: 'كيف تحب أن تكون خلفية التطبيق عادةً؟',
    description:
        'يمكن أن تكون الخلفية فاتحة أو داكنة، '
        'أو يمكن دعم الشكلين معًا.',
    type: QuestionType.singleChoice,
    options: [
      'فاتحة، مثل التطبيقات ذات الخلفية البيضاء',
      'داكنة، مثل التطبيقات ذات الخلفية السوداء',
      'أريد الوضعين مع إمكانية التبديل',
      'لا فرق لدي',
    ],
  ),

  DesignQuestion(
    id: 'gradient_mode',
    title: 'كيف تريد أن تبدو الخلفيات الملونة؟',
    description:
        'اختر شكل الخلفية وشاهد النتيجة مباشرة. '
        'لا يظهر التدرج إلا عندما تختاره.',
    type: QuestionType.gradientChoice,
    options: ['none', 'primary_accent', 'primary_custom'],
  ),
  DesignQuestion(
    id: 'borders',
    title: 'كيف تفضل أن تكون إطارات البطاقات؟',
    description:
        'شاهد الفرق بين البطاقات دون إطار '
        'والبطاقات ذات الإطار الخفيف أو الواضح.',
    type: QuestionType.borderPreview,
    options: ['دون إطار', 'إطار خفيف', 'إطار متوسط', 'إطار واضح'],
  ),

  DesignQuestion(
    id: 'border_color_mode',
    title: 'ما اللون الذي تفضله لإطارات البطاقات؟',
    description:
        'الإطار هو الخط المحيط بالبطاقة. '
        'اختر طريقة تلوينه وشاهد النتيجة مباشرة.',
    type: QuestionType.borderColorChoice,
    options: [
      'تلقائي ومتناسق مع التصميم',
      'نفس اللون الإضافي الذي اخترته',
      'أريد اختيار لون خاص للإطارات',
    ],
  ),

  DesignQuestion(
    id: 'formality',
    title: 'كيف تريد أن تكون شخصية التطبيق؟',
    description: 'هل تريده مرحًا وشبابيًا أم جديًا ورسميًا؟',
    type: QuestionType.scale,
    options: [
      'مرح جدًا',
      'مرح قليلًا',
      'متوازن',
      'جدي إلى حد ما',
      'رسمي وجدي جدًا',
    ],
  ),
  DesignQuestion(
    id: 'simplicity',
    title: 'ما مقدار التفاصيل الذي تحبه في التصميم؟',
    description:
        'هل تفضل تصميمًا بسيطًا جدًا أم تصميمًا '
        'يحتوي على تفاصيل وعناصر بصرية أكثر؟',
    type: QuestionType.scale,
    options: ['بسيط جدًا', 'بسيط', 'متوازن', 'غني بالتفاصيل', 'كثير التفاصيل'],
  ),
  DesignQuestion(
    id: 'visual_strength',
    title: 'إلى أي درجة تريد أن يلفت التصميم الأنظار؟',
    description:
        'هل تفضل مظهرًا هادئًا ومريحًا '
        'أم مظهرًا قويًا وملفتًا للنظر؟',
    type: QuestionType.scale,
    options: ['هادئ جدًا', 'هادئ', 'متوازن', 'قوي', 'قوي وملفت جدًا'],
  ),
  DesignQuestion(
    id: 'futurism',
    title: 'هل تفضل مظهرًا مألوفًا أم مبتكرًا ومستقبليًا؟',
    description:
        'التصميم المألوف يشبه التطبيقات التقليدية، '
        'أما المستقبلي فيستخدم أشكالًا وأساليب غير معتادة.',
    type: QuestionType.scale,
    options: [
      'تقليدي جدًا',
      'تقليدي قليلًا',
      'متوازن',
      'حديث ومبتكر',
      'مستقبلي جدًا',
    ],
  ),
  DesignQuestion(
    id: 'preferred_shapes',
    title: 'ما نوع الأشكال التي تحب رؤيتها في التطبيق؟',
    description:
        'اختر الشكل الأقرب لذوقك. '
        'سترى تأثيره مباشرة في المعاينة.',
    type: QuestionType.shapePreview,
    options: [
      'مستطيلات',
      'مستطيلات بحواف دائرية',
      'دوائر',
      'أشكال هندسية متنوعة',
      'أشكال ناعمة وغير منتظمة',
      'مزيج من عدة أشكال',
    ],
  ),
];

// ---------------- QUESTIONNAIRE ----------------

class QuestionnaireScreen extends StatefulWidget {
  const QuestionnaireScreen({super.key});

  @override
  State<QuestionnaireScreen> createState() => _QuestionnaireScreenState();
}

class _QuestionnaireScreenState extends State<QuestionnaireScreen> {
  int currentIndex = 0;

  final Map<String, List<String>> answers = {};

  DesignQuestion get currentQuestion => questions[currentIndex];

  List<String> get selectedAnswers => answers[currentQuestion.id] ?? [];

  void selectOption(String option) {
    final question = currentQuestion;
    final selected = List<String>.from(answers[question.id] ?? []);

    if (question.type == QuestionType.multiChoice) {
      if (selected.contains(option)) {
        selected.remove(option);
      } else if (selected.length < question.maxSelections) {
        selected.add(option);
      }
    } else {
      selected
        ..clear()
        ..add(option);
    }

    setState(() {
      answers[question.id] = selected;
    });
  }

  void toggleAvoidedColor(String hex) {
    const questionId = 'avoided_colors';

    final selected = List<String>.from(answers[questionId] ?? []);

    if (selected.contains(hex)) {
      selected.remove(hex);
    } else {
      selected.add(hex);
    }

    setState(() {
      answers[questionId] = selected;
    });
  }

  void nextQuestion() {
    if (currentIndex < questions.length - 1) {
      setState(() => currentIndex++);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => ReviewScreen(answers: answers)),
      );
    }
  }

  void previousQuestion() {
    if (currentIndex > 0) {
      setState(() => currentIndex--);
    } else {
      Navigator.pop(context);
    }
  }

  Widget buildQuestionContent(DesignQuestion question) {
    if (question.type == QuestionType.scale) {
      return ScaleQuestionWidget(
        options: question.options,
        selectedValue: selectedAnswers.firstOrNull,
        onSelected: selectOption,
      );
    }
    if (question.type == QuestionType.borderColorChoice) {
      final customColors = answers['border_custom_color'] ?? [];

      return ListView(
        children: [
          for (final option in question.options)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                title: Text(option),
                leading: Icon(
                  selectedAnswers.contains(option)
                      ? Icons.check_circle
                      : Icons.radio_button_unchecked,
                ),
                onTap: () => selectOption(option),
                tileColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          if (selectedAnswers.contains('أريد اختيار لون خاص للإطارات'))
            SizedBox(
              height: 420,
              child: ColorQuestionWidget(
                selectedValue: customColors.isEmpty ? null : customColors.first,
                onSelected: (value) {
                  setState(() {
                    answers['border_custom_color'] = [value];
                  });
                },
              ),
            ),
        ],
      );
    }

    if (question.type == QuestionType.colorChoice) {
      final isPrimary = question.id == 'primary_color';

      final savedStrength = answers['primary_color_strength']?.firstOrNull;

      final strength = double.tryParse(savedStrength ?? '') ?? 60.0;

      final colorPicker = ColorQuestionWidget(
        selectedValue: selectedAnswers.isEmpty ? null : selectedAnswers.first,
        onSelected: selectOption,
      );

      if (!isPrimary) {
        return colorPicker;
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(child: colorPicker),

          const SizedBox(height: 12),

          Text(
            'ما مدى ظهور اللون الأساسي في التصميم؟',
            style: Theme.of(context).textTheme.titleMedium,
          ),

          const SizedBox(height: 6),

          Text(
            'اسحب المؤشر لترى كيف تتغير ألوان '
            'الخلفيات والبطاقات.',
            style: Theme.of(context).textTheme.bodySmall,
          ),

          Slider(
            min: 0,
            max: 100,
            divisions: 20,
            value: strength,
            label: '${strength.round()}%',
            onChanged: (value) {
              setState(() {
                answers['primary_color_strength'] = [value.round().toString()];
              });
            },
          ),

          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text('تأثير خفيف'), Text('تأثير قوي')],
          ),

          const SizedBox(height: 8),
        ],
      );
    }

    if (question.type == QuestionType.colorAvoid) {
      return AvoidColorsWidget(
        selectedValues: selectedAnswers,
        onToggle: toggleAvoidedColor,
      );
    }

    if (question.type == QuestionType.colorStylePreview) {
      return ColorStyleWidget(
        options: question.options,
        selectedValue: selectedAnswers.isEmpty ? null : selectedAnswers.first,
        onSelected: selectOption,
      );
    }

    if (question.type == QuestionType.gradientChoice) {
      final customColors = answers['gradient_custom_color'] ?? [];

      final savedDirection =
          answers['gradient_direction']?.firstOrNull ?? 'diagonal';

      final savedBalance =
          double.tryParse(answers['gradient_balance']?.firstOrNull ?? '') ??
          50.0;

      Color parseColor(String? hex) {
        if (hex == null || !RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(hex)) {
          return const Color(0xFF64748B);
        }

        return Color(int.parse(hex.substring(1), radix: 16) | 0xFF000000);
      }

      final mode = selectedAnswers.firstOrNull;

      final firstColor = parseColor(answers['primary_color']?.firstOrNull);

      final secondColor = parseColor(
        mode == 'primary_custom'
            ? customColors.firstOrNull
            : answers['accent_color']?.firstOrNull,
      );

      return GradientQuestionWidget(
        selectedMode: mode,
        customColor: customColors.firstOrNull,
        firstColor: firstColor,
        secondColor: secondColor,
        direction: savedDirection,
        balance: savedBalance,
        onModeSelected: selectOption,
        onCustomColorSelected: (value) {
          setState(() {
            answers['gradient_custom_color'] = [value];
          });
        },
        onDirectionChanged: (value) {
          setState(() {
            answers['gradient_direction'] = [value];
          });
        },
        onBalanceChanged: (value) {
          setState(() {
            answers['gradient_balance'] = [value.round().toString()];
          });
        },
      );
    }

    return ListView.builder(
      itemCount: question.options.length,
      itemBuilder: (context, index) {
        final option = question.options[index];
        final selected = selectedAnswers.contains(option);

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: VisualChoiceCard(
            questionType: question.type,
            option: option,
            index: index,
            selected: selected,
            onTap: () => selectOption(option),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = currentQuestion;

    return Scaffold(
      appBar: AppBar(title: const Text('اكتشف ذوقك في التصميم')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              LinearProgressIndicator(
                value: (currentIndex + 1) / questions.length,
                minHeight: 7,
                borderRadius: BorderRadius.circular(10),
              ),
              const SizedBox(height: 14),
              Text(
                'السؤال ${currentIndex + 1} '
                'من ${questions.length}',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
              const SizedBox(height: 20),
              Text(
                question.title,
                style: Theme.of(context).textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                question.description,
                style: const TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 18),

              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isDesktop = constraints.maxWidth >= 800;

                    final questionArea = Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: buildQuestionContent(question)),
                      ],
                    );

                    final previewArea = Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              Icon(Icons.visibility_outlined, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'معاينة تصميمك',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        Expanded(child: LiveDesignPreview(answers: answers)),
                      ],
                    );

                    if (isDesktop) {
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(flex: 5, child: questionArea),
                          const SizedBox(width: 20),
                          Expanded(flex: 4, child: previewArea),
                        ],
                      );
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: questionArea),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: constraints.maxHeight * 0.42,
                          child: previewArea,
                        ),
                      ],
                    );
                  },
                ),
              ),

              TextButton(
                onPressed: nextQuestion,
                child: const Text('تخطي السؤال دون اختيار'),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: previousQuestion,
                      child: const Text('السابق'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: nextQuestion,
                      child: Text(
                        currentIndex == questions.length - 1
                            ? 'مراجعة الإجابات'
                            : 'التالي',
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- VISUAL CHOICE CARD ----------------

class VisualChoiceCard extends StatelessWidget {
  final QuestionType questionType;
  final String option;
  final int index;
  final bool selected;
  final VoidCallback onTap;

  const VisualChoiceCard({
    super.key,
    required this.questionType,
    required this.option,
    required this.index,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final hasPreview =
        questionType == QuestionType.cornerPreview ||
        questionType == QuestionType.shadowPreview ||
        questionType == QuestionType.glassPreview ||
        questionType == QuestionType.borderPreview ||
        questionType == QuestionType.shapePreview;

    return Material(
      color: selected ? const Color(0xFFE8F0FF) : Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? primary : const Color(0xFFE0E5ED),
              width: selected ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Icon(
                    selected
                        ? Icons.check_circle
                        : Icons.radio_button_unchecked,
                    color: selected ? primary : Colors.grey,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      option,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              if (hasPreview) ...[
                const SizedBox(height: 16),
                if (questionType == QuestionType.cornerPreview)
                  CornerPreview(index: index),
                if (questionType == QuestionType.shadowPreview)
                  ShadowPreview(index: index),
                if (questionType == QuestionType.glassPreview)
                  GlassPreview(index: index),
                if (questionType == QuestionType.borderPreview)
                  BorderPreview(index: index),
                if (questionType == QuestionType.shapePreview)
                  ShapeOptionPreview(index: index),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- CORNER PREVIEW ----------------

class CornerPreview extends StatelessWidget {
  final int index;

  const CornerPreview({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    const radii = [0.0, 6.0, 14.0, 24.0, 36.0];

    return Center(
      child: Container(
        width: 200,
        height: 82,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: const Color(0xFF2455A4),
          borderRadius: BorderRadius.circular(radii[index]),
        ),
        child: const Text(
          'بطاقة تجريبية',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
      ),
    );
  }
}

// ---------------- SHADOW PREVIEW ----------------

class ShadowPreview extends StatelessWidget {
  final int index;

  const ShadowPreview({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    const blur = [0.0, 8.0, 18.0, 30.0];
    const offset = [0.0, 3.0, 7.0, 13.0];

    return Container(
      height: 120,
      alignment: Alignment.center,
      color: const Color(0xFFF3F5F9),
      child: Container(
        width: 190,
        height: 76,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE1E5EC)),
          boxShadow: index == 0
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.12 + index * 0.035),
                    blurRadius: blur[index],
                    offset: Offset(0, offset[index]),
                  ),
                ],
        ),
        child: const Text('بطاقة تجريبية'),
      ),
    );
  }
}

// ---------------- GLASS PREVIEW ----------------

class GlassPreview extends StatelessWidget {
  final int index;

  const GlassPreview({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    const transparency = [1.0, 0.88, 0.65, 0.38, 0.18];

    const blur = [0.0, 2.0, 5.0, 9.0, 14.0];

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: SizedBox(
        height: 140,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF2559C9),
                    Color(0xFF9B67D8),
                    Color(0xFFED84AB),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 15,
              top: 12,
              child: Container(
                width: 85,
                height: 85,
                decoration: const BoxDecoration(
                  color: Color(0xAAFFCF50),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              right: 28,
              bottom: 0,
              child: Container(
                width: 95,
                height: 95,
                decoration: const BoxDecoration(
                  color: Color(0xAA36DBD2),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: blur[index],
                  sigmaY: blur[index],
                ),
                child: Container(
                  width: 220,
                  height: 90,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: transparency[index]),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white70),
                  ),
                  child: const Text(
                    'بطاقة تجريبية',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF142D53),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- REVIEW ----------------

class ReviewScreen extends StatelessWidget {
  final Map<String, List<String>> answers;

  const ReviewScreen({super.key, required this.answers});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة الاختيارات')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'هذه تفضيلات التصميم التي اخترتها',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          ...questions.map((question) {
            final selected = answers[question.id] ?? [];

            return Card(
              child: ListTile(
                title: Text(question.title),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    selected.isEmpty
                        ? 'لم يحدد العميل تفضيلًا'
                        : selected.join('، '),
                  ),
                ),
              ),
            );
          }),
          const SizedBox(height: 20),
          const Text(
            'هذه نسخة تجريبية للأسئلة البصرية. '
            'سنضيف لاحقًا توليد الهوية البصرية '
            'والمواصفات الاحترافية.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class BorderPreview extends StatelessWidget {
  final int index;

  const BorderPreview({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    const widths = [0.0, 0.8, 1.8, 3.5];

    return Container(
      height: 100,
      alignment: Alignment.center,
      color: const Color(0xFFF1F3F6),
      child: Container(
        width: 220,
        height: 72,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: widths[index] == 0
              ? null
              : Border.all(
                  color: const Color(0xFF475569),
                  width: widths[index],
                ),
        ),
        child: const Text('بطاقة تجريبية'),
      ),
    );
  }
}


class ShapeOptionPreview extends StatelessWidget {
  final int index;

  const ShapeOptionPreview({
    super.key,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    Widget shape({
      required double width,
      required double height,
      required ShapeBorder border,
    }) {
      return Material(
        color: const Color(0xFF64748B),
        shape: border,
        child: SizedBox(width: width, height: height),
      );
    }

    final Widget preview;

    switch (index) {
      case 0:
        preview = shape(
          width: 135,
          height: 65,
          border: const RoundedRectangleBorder(),
        );
        break;

      case 1:
        preview = shape(
          width: 135,
          height: 65,
          border: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        );
        break;

      case 2:
        preview = shape(
          width: 75,
          height: 75,
          border: const CircleBorder(),
        );
        break;

      case 3:
        preview = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            shape(
              width: 65,
              height: 65,
              border: const CircleBorder(),
            ),
            const SizedBox(width: 12),
            shape(
              width: 65,
              height: 65,
              border: const BeveledRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(18),
                ),
              ),
            ),
          ],
        );
        break;

      case 4:
        preview = ClipPath(
          clipper: _OrganicShapeClipper(),
          child: Container(
            width: 125,
            height: 85,
            color: const Color(0xFF64748B),
          ),
        );
        break;

      default:
        preview = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            shape(
              width: 65,
              height: 65,
              border: const CircleBorder(),
            ),
            const SizedBox(width: 12),
            shape(
              width: 85,
              height: 65,
              border: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ],
        );
    }

    return Container(
      height: 110,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F3F6),
        borderRadius: BorderRadius.circular(12),
      ),
      child: preview,
    );
  }
}

class _OrganicShapeClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    return Path()
      ..moveTo(size.width * 0.18, size.height * 0.05)
      ..cubicTo(
        size.width * 0.70, -size.height * 0.10,
        size.width * 1.10, size.height * 0.25,
        size.width * 0.88, size.height * 0.65,
      )
      ..cubicTo(
        size.width * 0.70, size.height * 1.10,
        size.width * 0.15, size.height * 1.10,
        size.width * 0.05, size.height * 0.65,
      )
      ..cubicTo(
        -size.width * 0.10, size.height * 0.25,
        size.width * 0.05, size.height * 0.12,
        size.width * 0.18, size.height * 0.05,
      )
      ..close();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}
